console.log("im an external js");

// operators
// arithmetic operation:

let num1=10;
let num2=15;
console.log(num1+num2);
console.log(num1-num2);
console.log(num1*num2);
console.log(num1/num2);
console.log(num1%num2);

// relational operator




console.log(num1>num2);
console.log(num1>=num2);
console.log(num1<num2);
console.log(num1<=num2);
console.log(num1==num2);
console.log(num1!=num2);

// converting number into string type qourcent
let num3=2;
let num4="3";
console.log(num3+num4);

let num5=2;
let num6="there";
console.log(num5+num6);
console.log(num5-num6); 
//  not a number ===  !==
console.log(num5===num6);

// logical operator && || !
console.log(2==2 && 3>1)


//increment and decrementy operator 
// .pre increment ++i
// .post increment i++
// same for decrement

let n=34;
n++;
console.log(n);

let a=++n;
console.log(n,a)



// conditional statement
let condition=3;
if(condition===9)
    {
        console.log("the condition is true");
    }
else
{
    console.log("false block");
}

// 2

let percentage=7;
if(percentage>=70)
    {
        console.log("b grade");
    }
    else if(percentage>=60)
        {
            console.log("c grade");

        }
else if(percentage>=50)
    {
        console.log("d grade")
    }
    else
    {
        console.log("fail")
    }
// 3

let percentagee=77;
if(percentagee>=90 && percentagee<100)
    {
        console.log("o grade");
    }
else if(percentagee>=80 && percentagee<90)
    {
        console.log("a grade")
    }
    else if(percentagee>=70 && percentagee<80)
        {
            console.log("b grade")
        }
        else if(percentagee>=60&& percentagee<70)
            {
                console.log("c grade")
            }
            else
            {
                console.log("no grade")
            }

            // type converction

            let p="23"


            console.log(2+ Number(p));

            // number to string
            let d=34;
            console.log(2+d.toString());


            // switch case

            let star=1;
            switch(star)
            {
            case 1:
                {
                    console.log("super  1 star");
                    break;
                }
                case 2:
                    {
                        console.log("2nd star");
                        break;

                    }
                    case 3:
                        {
                            console.log("3ed star");
                            break;
                        }
                        default:
                            {
                                console.log("error");
                            }
                        }



                            // ternary operator:


                            
                             let age=16;

                             let val=age>=18?1:2;
                             console.log(val);

// conditional operator  
// for
// while entry control loop
// do while exit control loop

let aa=1;
while(d<10)
    {
        console.log("lets learn");
        aa++;
    }


    let b=1;
    do
    {
        console.log("lets learn"+b);
        b++;
    }
    while(b<10)


        
        for(let cc=1;cc<=10;cc++)
            {
                
                if(cc==4)
                    {
                        // break;
                        continue;
                    }
                    console.log("the value is:"+cc)

                    
            }
            

            // array
k w

            // let city="mumbai";
            // let city2="coimbatore";
            // let city3="chennai";
            let cities=["mumbai","chennai","cbe"]
            console.log(cities[1]);